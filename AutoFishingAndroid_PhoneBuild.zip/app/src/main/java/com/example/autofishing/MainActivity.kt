package com.example.autofishing

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
        }
        val title = TextView(this).apply {
            text = "Auto Fishing"
            textSize = 26f
        }
        val info = TextView(this).apply {
            text = "1) 접근성 권한을 켜세요.\n2) Roblox에서 낚시 화면을 띄우세요.\n3) 아래 시작 버튼을 누르세요.\n\n감지 방식: Android 접근성 텍스트"
            textSize = 16f
            setPadding(0, 24, 0, 24)
        }
        val settings = Button(this).apply {
            text = "접근성 설정 열기"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val start = Button(this).apply {
            text = "자동화 시작"
            setOnClickListener {
                getSharedPreferences("auto_fishing", MODE_PRIVATE).edit().putBoolean("enabled", true).apply()
                info.text = "자동화가 켜졌어요. Roblox로 돌아가세요.\n\n중지하려면 앱으로 돌아와 중지 버튼을 누르세요."
            }
        }
        val stop = Button(this).apply {
            text = "자동화 중지"
            setOnClickListener {
                getSharedPreferences("auto_fishing", MODE_PRIVATE).edit().putBoolean("enabled", false).apply()
                info.text = "자동화가 중지됐어요."
            }
        }
        layout.addView(title)
        layout.addView(info)
        layout.addView(settings)
        layout.addView(start)
        layout.addView(stop)
        setContentView(layout)
    }
}
