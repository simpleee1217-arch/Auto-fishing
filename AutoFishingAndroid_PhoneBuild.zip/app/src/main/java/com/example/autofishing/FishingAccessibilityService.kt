package com.example.autofishing

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class FishingAccessibilityService : AccessibilityService() {
    private var lastActionAt = 0L
    private var quickTapCount = 0
    private var lastMode = ""

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!getSharedPreferences("auto_fishing", MODE_PRIVATE).getBoolean("enabled", false)) return
        if (event == null) return

        val root = rootInActiveWindow ?: return
        val nodes = mutableListOf<AccessibilityNodeInfo>()
        collectNodes(root, nodes)

        val castNode = nodes.firstOrNull { nodeText(it).contains("길게 눌러 캐스팅하기") }
        val quickNode = nodes.firstOrNull { nodeText(it).contains("빠르게 클릭하세요") }

        val now = SystemClock.elapsedRealtime()
        if (castNode != null && now - lastActionAt > 2500 && lastMode != "cast") {
            val bounds = Rect()
            castNode.getBoundsInScreen(bounds)
            if (!bounds.isEmpty) {
                lastMode = "cast"
                lastActionAt = now
                dispatchPress(bounds.centerX().toFloat(), bounds.centerY().toFloat(), 2000)
            }
            return
        }

        if (quickNode != null && now - lastActionAt > 90) {
            val bounds = Rect()
            quickNode.getBoundsInScreen(bounds)
            if (!bounds.isEmpty) {
                lastMode = "quick"
                lastActionAt = now
                quickTapCount++
                dispatchTap(bounds.centerX().toFloat(), bounds.centerY().toFloat())
            }
            return
        }

        if (castNode == null && quickNode == null) {
            lastMode = ""
            quickTapCount = 0
        }
    }

    private fun collectNodes(node: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>) {
        out.add(node)
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { collectNodes(it, out) }
        }
    }

    private fun nodeText(node: AccessibilityNodeInfo): String {
        return listOfNotNull(node.text?.toString(), node.contentDescription?.toString())
            .joinToString(" ")
    }

    private fun dispatchPress(x: Float, y: Float, durationMs: Long) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()
        dispatchGesture(gesture, null, null)
    }

    private fun dispatchTap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 45))
            .build()
        dispatchGesture(gesture, null, null)
    }

    override fun onInterrupt() = Unit
}
